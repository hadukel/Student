﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExam
    Inherits DevComponents.DotNetBar.OfficeForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IDLabel As System.Windows.Forms.Label
        Dim Stud_IDLabel As System.Windows.Forms.Label
        Dim QuestionIDLabel As System.Windows.Forms.Label
        Dim Question_AnswerLabel As System.Windows.Forms.Label
        Dim Stud_AnswerLabel As System.Windows.Forms.Label
        Me.StudentdbDataSet = New PROJECT2.StudentdbDataSet()
        Me.ExamBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ExamTableAdapter = New PROJECT2.StudentdbDataSetTableAdapters.ExamTableAdapter()
        Me.TableAdapterManager = New PROJECT2.StudentdbDataSetTableAdapters.TableAdapterManager()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Stud_IDTextBox = New System.Windows.Forms.TextBox()
        Me.QuestionIDTextBox = New System.Windows.Forms.TextBox()
        Me.Question_AnswerTextBox = New System.Windows.Forms.TextBox()
        Me.Stud_AnswerTextBox = New System.Windows.Forms.TextBox()
        Me.ButtonX1 = New DevComponents.DotNetBar.ButtonX()
        IDLabel = New System.Windows.Forms.Label()
        Stud_IDLabel = New System.Windows.Forms.Label()
        QuestionIDLabel = New System.Windows.Forms.Label()
        Question_AnswerLabel = New System.Windows.Forms.Label()
        Stud_AnswerLabel = New System.Windows.Forms.Label()
        CType(Me.StudentdbDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ExamBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Location = New System.Drawing.Point(50, 36)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(21, 13)
        IDLabel.TabIndex = 1
        IDLabel.Text = "ID:"
        '
        'Stud_IDLabel
        '
        Stud_IDLabel.AutoSize = True
        Stud_IDLabel.Location = New System.Drawing.Point(50, 62)
        Stud_IDLabel.Name = "Stud_IDLabel"
        Stud_IDLabel.Size = New System.Drawing.Size(46, 13)
        Stud_IDLabel.TabIndex = 3
        Stud_IDLabel.Text = "Stud ID:"
        '
        'QuestionIDLabel
        '
        QuestionIDLabel.AutoSize = True
        QuestionIDLabel.Location = New System.Drawing.Point(50, 88)
        QuestionIDLabel.Name = "QuestionIDLabel"
        QuestionIDLabel.Size = New System.Drawing.Size(66, 13)
        QuestionIDLabel.TabIndex = 5
        QuestionIDLabel.Text = "Question ID:"
        '
        'Question_AnswerLabel
        '
        Question_AnswerLabel.AutoSize = True
        Question_AnswerLabel.Location = New System.Drawing.Point(50, 114)
        Question_AnswerLabel.Name = "Question_AnswerLabel"
        Question_AnswerLabel.Size = New System.Drawing.Size(90, 13)
        Question_AnswerLabel.TabIndex = 7
        Question_AnswerLabel.Text = "Question Answer:"
        '
        'Stud_AnswerLabel
        '
        Stud_AnswerLabel.AutoSize = True
        Stud_AnswerLabel.Location = New System.Drawing.Point(50, 140)
        Stud_AnswerLabel.Name = "Stud_AnswerLabel"
        Stud_AnswerLabel.Size = New System.Drawing.Size(70, 13)
        Stud_AnswerLabel.TabIndex = 9
        Stud_AnswerLabel.Text = "Stud Answer:"
        '
        'StudentdbDataSet
        '
        Me.StudentdbDataSet.DataSetName = "StudentdbDataSet"
        Me.StudentdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ExamBindingSource
        '
        Me.ExamBindingSource.DataMember = "Exam"
        Me.ExamBindingSource.DataSource = Me.StudentdbDataSet
        '
        'ExamTableAdapter
        '
        Me.ExamTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ExamTableAdapter = Me.ExamTableAdapter
        Me.TableAdapterManager.StudentTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = PROJECT2.StudentdbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ExamBindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(146, 33)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(360, 20)
        Me.IDTextBox.TabIndex = 2
        '
        'Stud_IDTextBox
        '
        Me.Stud_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ExamBindingSource, "Stud_ID", True))
        Me.Stud_IDTextBox.Location = New System.Drawing.Point(146, 59)
        Me.Stud_IDTextBox.Name = "Stud_IDTextBox"
        Me.Stud_IDTextBox.Size = New System.Drawing.Size(360, 20)
        Me.Stud_IDTextBox.TabIndex = 4
        '
        'QuestionIDTextBox
        '
        Me.QuestionIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ExamBindingSource, "QuestionID", True))
        Me.QuestionIDTextBox.Location = New System.Drawing.Point(146, 85)
        Me.QuestionIDTextBox.Name = "QuestionIDTextBox"
        Me.QuestionIDTextBox.Size = New System.Drawing.Size(360, 20)
        Me.QuestionIDTextBox.TabIndex = 6
        '
        'Question_AnswerTextBox
        '
        Me.Question_AnswerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ExamBindingSource, "Question_Answer", True))
        Me.Question_AnswerTextBox.Location = New System.Drawing.Point(146, 111)
        Me.Question_AnswerTextBox.Name = "Question_AnswerTextBox"
        Me.Question_AnswerTextBox.Size = New System.Drawing.Size(360, 20)
        Me.Question_AnswerTextBox.TabIndex = 8
        '
        'Stud_AnswerTextBox
        '
        Me.Stud_AnswerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ExamBindingSource, "Stud_Answer", True))
        Me.Stud_AnswerTextBox.Location = New System.Drawing.Point(146, 137)
        Me.Stud_AnswerTextBox.Name = "Stud_AnswerTextBox"
        Me.Stud_AnswerTextBox.Size = New System.Drawing.Size(360, 20)
        Me.Stud_AnswerTextBox.TabIndex = 10
        '
        'ButtonX1
        '
        Me.ButtonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX1.Location = New System.Drawing.Point(431, 175)
        Me.ButtonX1.Name = "ButtonX1"
        Me.ButtonX1.Size = New System.Drawing.Size(75, 23)
        Me.ButtonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled
        Me.ButtonX1.TabIndex = 11
        Me.ButtonX1.Text = "SAVE"
        '
        'frmExam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 210)
        Me.Controls.Add(Me.ButtonX1)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(Stud_IDLabel)
        Me.Controls.Add(Me.Stud_IDTextBox)
        Me.Controls.Add(QuestionIDLabel)
        Me.Controls.Add(Me.QuestionIDTextBox)
        Me.Controls.Add(Question_AnswerLabel)
        Me.Controls.Add(Me.Question_AnswerTextBox)
        Me.Controls.Add(Stud_AnswerLabel)
        Me.Controls.Add(Me.Stud_AnswerTextBox)
        Me.DoubleBuffered = True
        Me.Name = "frmExam"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exam Form"
        CType(Me.StudentdbDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ExamBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StudentdbDataSet As PROJECT2.StudentdbDataSet
    Friend WithEvents ExamBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ExamTableAdapter As PROJECT2.StudentdbDataSetTableAdapters.ExamTableAdapter
    Friend WithEvents TableAdapterManager As PROJECT2.StudentdbDataSetTableAdapters.TableAdapterManager
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Stud_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents QuestionIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Question_AnswerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Stud_AnswerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ButtonX1 As DevComponents.DotNetBar.ButtonX

End Class
