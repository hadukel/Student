﻿Public Class frmExam

    Private Sub ExamBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ExamBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentdbDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentdbDataSet.Exam' table. You can move, or remove it, as needed.
        Me.ExamTableAdapter.Fill(Me.StudentdbDataSet.Exam)
        Me.ExamBindingSource.AddNew()
    End Sub
End Class
